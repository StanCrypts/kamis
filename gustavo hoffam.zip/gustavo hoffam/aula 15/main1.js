
    const botaoCadrastar = document.getElementById("btnCadastrar");

    botaoCadrastar.addEventListener("click", function () {
      alert('Cadastro realizado com sucesso!');
    });
 
